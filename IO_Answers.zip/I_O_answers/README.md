## I/O Input and Solution

- `*_input`: The first line is the `stdin` and the second line is the time difference (w.r.t the previous `SIGTSTP`)
    to kill `SIGTSTP` to the running process.

- `*_solution`: The `stdout` solution.

- `sample_1*` is used for Testcase 1. For other testcases,  `sample_2*` is used. For example, `testcase_0.3` used
    `sample_2.3_input`.

- `sample_1.1` == `public_test_case 1`
- `sample_2.2` == `public_test_case 2`
- `sample_2.3` == `public_test_case 3`

